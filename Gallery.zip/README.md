# Gallery Creator

A Google Chrome extension to instantly create a gallery and slideshow from the images on a page or from saved images. Still under developement
